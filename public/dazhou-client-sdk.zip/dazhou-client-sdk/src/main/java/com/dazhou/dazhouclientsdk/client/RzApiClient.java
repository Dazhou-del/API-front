package com.dazhou.dazhouclientsdk.client;

import cn.hutool.core.util.CharsetUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.URLUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONUtil;
import com.dazhou.dazhouclientsdk.util.SignUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * 调用我们写的api
 * 使用hutool来发起请求
 *
 * @author dazhou
 * @create 2023-07-30 22:00
 */
public class RzApiClient {
    public static String GATEWAY_HOST = "43.136.14.135:8090";
    private String accessKey;
    private String secretKey;


    public RzApiClient(String accessKey, String secretKey) {
        this.accessKey = accessKey;
        this.secretKey = secretKey;
    }

    public void setGatewayHost(String host) {
        GATEWAY_HOST = host;
    }


    /**
     * 要发送的参数
     *
     * @param body
     * @return
     */
    private Map<String, String> getHeadrMap(String body, String method) {
        Map<String, String> hashMap = new HashMap<>();
        hashMap.put("accessKey", accessKey);
        hashMap.put("nonce", RandomUtil.randomNumbers(8));
        //把字符格式设置为utf-8
        URLUtil.encode(body, CharsetUtil.CHARSET_UTF_8);
        hashMap.put("body", body);
        hashMap.put("timestamp", String.valueOf(System.currentTimeMillis() / 1000));
        hashMap.put("sign", SignUtils.getSign(body, secretKey));
        hashMap.put("method", method);
        return hashMap;
    }

    /**
     * 调用api
     * GATEWAY_HOST + url  : http://localhost:8090/api/name/user
     *
     * @param params
     * @param url
     * @param method
     * @return
     */
    public String executeApi(String params, String url, String method) {
        String esw = GATEWAY_HOST + url;
        HttpResponse httpResponse = HttpRequest.post(esw)
                .header("Accept-Charset", CharsetUtil.UTF_8)
                .addHeaders(getHeadrMap(params, method))
                .body(params)
                .execute();
        return JSONUtil.formatJsonStr(httpResponse.body());
    }

}
