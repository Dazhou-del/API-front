package com.dazhou.dazhouclientsdk;

import com.dazhou.dazhouclientsdk.client.RzApiClient;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author dazhou
 * @create 2023-07-31 10:49
 */
@Configuration
@ConfigurationProperties("dzapi.client")
@Data
@ComponentScan
public class DzApiClientConfig {
    private String accessKey;
    private String secretKey;


    @Bean
    public RzApiClient rzApiClient() {
        return new RzApiClient(accessKey, secretKey);
    }
}
