package com.dazhou.dazhouclientsdk.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author dazhou
 * @create 2023-07-30 21:39
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {

    private String username;

    /**
     * 主机号
     */
    private String host;
}
